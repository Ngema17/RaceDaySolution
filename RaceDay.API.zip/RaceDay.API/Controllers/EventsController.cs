﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EventsController(AppDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Retrieves a list of all events.
        /// </summary>
        /// <returns>A list of events.</returns>
        [HttpGet]
        public async Task<IActionResult> GetAllEvents()
        {
            var events = await _context.Events.ToListAsync();
            return Ok(events);
        }

        /// <summary>
        /// Creates a new event. (Organiser access only)
        /// </summary>
        /// <param name="newEvent">The event details (name, date, location, type).</param>
        /// <returns>The ID of the created event.</returns>
        [HttpPost]
        public async Task<IActionResult> CreateEvent([FromBody] Event newEvent)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role == null || userId == null) return Unauthorized("Please log in.");
            if (role != "Organiser") return Forbid("Only Organisers can create events.");

            newEvent.OrganiserId = userId.Value;

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Event created successfully!", eventId = newEvent.Id });
        }

        /// <summary>
        /// Updates an existing event. (Organiser access only)
        /// </summary>
        /// <param name="id">The ID of the event to update.</param>
        /// <param name="updatedEvent">The updated event details.</param>
        /// <returns>A success message.</returns>
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] Event updatedEvent)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role != "Organiser" || userId == null) return Forbid("Only Organisers can update events.");

            var existingEvent = await _context.Events.FindAsync(id);
            if (existingEvent == null) return NotFound("Event not found.");

            // Ensure the organiser owns the event
            if (existingEvent.OrganiserId != userId) return Forbid("You can only update your own events.");

            existingEvent.Name = updatedEvent.Name;
            existingEvent.Description = updatedEvent.Description;
            existingEvent.Date = updatedEvent.Date;
            existingEvent.Location = updatedEvent.Location;
            existingEvent.Distance = updatedEvent.Distance;
            existingEvent.EventType = updatedEvent.EventType;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Event updated successfully." });
        }

        /// <summary>
        /// Deletes an event. (Organiser access only)
        /// </summary>
        /// <param name="id">The ID of the event to delete.</param>
        /// <returns>A success message.</returns>
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var role = HttpContext.Session.GetString("UserRole");
            var userId = HttpContext.Session.GetInt32("UserId");

            if (role != "Organiser" || userId == null) return Forbid("Only Organisers can delete events.");

            var eventToDelete = await _context.Events.FindAsync(id);
            if (eventToDelete == null) return NotFound("Event not found.");
            if (eventToDelete.OrganiserId != userId) return Forbid("You can only delete your own events.");

            _context.Events.Remove(eventToDelete);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Event deleted successfully." });
        }
    }
}