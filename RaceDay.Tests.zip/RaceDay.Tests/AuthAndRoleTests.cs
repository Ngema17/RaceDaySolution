﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Moq;
using System.Threading.Tasks;
using Xunit;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Controllers;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;

// This alias fixes the naming collision
using AppDbContext = RaceDay.API.Data.AppDbContext;
namespace RaceDay.Tests
{
    public class AuthAndRoleTests
    {
        private AppDbContext GetInMemoryDbContext()
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .Options;
            return new AppDbContext(options);
        }

        // Helper to mock HttpContext.Session
        private void SetupSession(ControllerBase controller, int? userId, string role)
        {
            var mockSession = new Mock<ISession>();

            mockSession.Setup(s => s.GetInt32("UserId")).Returns(userId);
            mockSession.Setup(s => s.GetString("UserRole")).Returns(role);

            var mockHttpContext = new Mock<HttpContext>();
            mockHttpContext.Setup(c => c.Session).Returns(mockSession.Object);

            controller.ControllerContext = new ControllerContext
            {
                HttpContext = mockHttpContext.Object
            };
        }

        [Fact]
        public async Task Register_ValidUser_ReturnsOk()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var controller = new AuthController(context);
            var request = new RegisterDto { FirstName = "Test", LastName = "User", Email = "test@test.com", Password = "Password123!", Role = "Participant" };

            // Act
            var result = await controller.Register(request);

            // Assert
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(1, await context.Users.CountAsync<RaceDay.API.Models.User>());
        }

        [Fact]
        public async Task Login_InvalidPassword_ReturnsUnauthorized()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            context.Users.Add(new User { Email = "test@test.com", PasswordHash = BCrypt.Net.BCrypt.HashPassword("CorrectPassword"), Role = "Participant" });
            await context.SaveChangesAsync();

            var controller = new AuthController(context);
            var request = new LoginDto { Email = "test@test.com", Password = "WrongPassword" };

            // Act
            var result = await controller.Login(request);

            // Assert
            Assert.IsType<UnauthorizedObjectResult>(result);
        }

        [Fact]
        public async Task CreateEvent_AsParticipant_ReturnsForbid()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var controller = new EventsController(context);

            // Simulate a Participant trying to create an event
            SetupSession(controller, 1, "Participant");
            var newEvent = new Event { Name = "Test Event" };

            // Act
            var result = await controller.CreateEvent(newEvent);

            // Assert
            Assert.IsType<ForbidResult>(result);
        }

        [Fact]
        public async Task CreateEvent_AsOrganiser_ReturnsOk()
        {
            // Arrange
            var context = GetInMemoryDbContext();
            var controller = new EventsController(context);

            // Simulate an Organiser trying to create an event
            SetupSession(controller, 1, "Organiser");
            var newEvent = new Event { Name = "Test Event", EventType = "run", Date = DateTime.Now };

            // Act
            var result = await controller.CreateEvent(newEvent);

            // Assert
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(1, await context.Users.CountAsync<RaceDay.API.Models.User>());
        }
    }
}